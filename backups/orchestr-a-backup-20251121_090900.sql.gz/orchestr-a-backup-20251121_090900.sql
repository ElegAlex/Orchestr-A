--
-- PostgreSQL database dump
--

\restrict qwvdIi7kRtgR75f1DUXmQ0jIn6DupfuflyOkIiALEXjHU9y23bF2wbZg8R3rXzl

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ActivityType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ActivityType" AS ENUM (
    'DEVELOPMENT',
    'MEETING',
    'SUPPORT',
    'TRAINING',
    'OTHER'
);


ALTER TYPE public."ActivityType" OWNER TO postgres;

--
-- Name: HalfDay; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."HalfDay" AS ENUM (
    'MORNING',
    'AFTERNOON'
);


ALTER TYPE public."HalfDay" OWNER TO postgres;

--
-- Name: LeaveStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."LeaveStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public."LeaveStatus" OWNER TO postgres;

--
-- Name: LeaveType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."LeaveType" AS ENUM (
    'CP',
    'RTT',
    'SICK_LEAVE',
    'UNPAID',
    'OTHER'
);


ALTER TYPE public."LeaveType" OWNER TO postgres;

--
-- Name: MilestoneStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."MilestoneStatus" AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'COMPLETED',
    'DELAYED'
);


ALTER TYPE public."MilestoneStatus" OWNER TO postgres;

--
-- Name: Priority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Priority" AS ENUM (
    'LOW',
    'NORMAL',
    'HIGH',
    'CRITICAL'
);


ALTER TYPE public."Priority" OWNER TO postgres;

--
-- Name: ProjectStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ProjectStatus" AS ENUM (
    'DRAFT',
    'ACTIVE',
    'SUSPENDED',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."ProjectStatus" OWNER TO postgres;

--
-- Name: RACIRole; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."RACIRole" AS ENUM (
    'RESPONSIBLE',
    'ACCOUNTABLE',
    'CONSULTED',
    'INFORMED'
);


ALTER TYPE public."RACIRole" OWNER TO postgres;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN',
    'RESPONSABLE',
    'MANAGER',
    'REFERENT_TECHNIQUE',
    'CONTRIBUTEUR',
    'OBSERVATEUR'
);


ALTER TYPE public."Role" OWNER TO postgres;

--
-- Name: SkillCategory; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SkillCategory" AS ENUM (
    'TECHNICAL',
    'METHODOLOGY',
    'SOFT_SKILL',
    'BUSINESS'
);


ALTER TYPE public."SkillCategory" OWNER TO postgres;

--
-- Name: SkillLevel; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SkillLevel" AS ENUM (
    'BEGINNER',
    'INTERMEDIATE',
    'EXPERT',
    'MASTER'
);


ALTER TYPE public."SkillLevel" OWNER TO postgres;

--
-- Name: TaskStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TaskStatus" AS ENUM (
    'TODO',
    'IN_PROGRESS',
    'IN_REVIEW',
    'DONE',
    'BLOCKED'
);


ALTER TYPE public."TaskStatus" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comments (
    id text NOT NULL,
    content text NOT NULL,
    "taskId" text NOT NULL,
    "authorId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.comments OWNER TO postgres;

--
-- Name: departments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.departments (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "managerId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.departments OWNER TO postgres;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.documents (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    url text NOT NULL,
    "mimeType" text NOT NULL,
    size integer NOT NULL,
    "projectId" text NOT NULL,
    "uploadedBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.documents OWNER TO postgres;

--
-- Name: epics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.epics (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "projectId" text NOT NULL,
    progress integer DEFAULT 0 NOT NULL,
    "startDate" timestamp(3) without time zone,
    "endDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.epics OWNER TO postgres;

--
-- Name: leaves; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.leaves (
    id text NOT NULL,
    "userId" text NOT NULL,
    type public."LeaveType" NOT NULL,
    "startDate" date NOT NULL,
    "endDate" date NOT NULL,
    "halfDay" public."HalfDay",
    days double precision NOT NULL,
    status public."LeaveStatus" DEFAULT 'APPROVED'::public."LeaveStatus" NOT NULL,
    comment text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.leaves OWNER TO postgres;

--
-- Name: milestones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.milestones (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "projectId" text NOT NULL,
    "dueDate" timestamp(3) without time zone NOT NULL,
    status public."MilestoneStatus" DEFAULT 'PENDING'::public."MilestoneStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.milestones OWNER TO postgres;

--
-- Name: personal_todos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personal_todos (
    id text NOT NULL,
    "userId" text NOT NULL,
    text text NOT NULL,
    completed boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.personal_todos OWNER TO postgres;

--
-- Name: project_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_members (
    id text NOT NULL,
    "projectId" text NOT NULL,
    "userId" text NOT NULL,
    role text NOT NULL,
    allocation integer,
    "startDate" timestamp(3) without time zone,
    "endDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.project_members OWNER TO postgres;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projects (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    status public."ProjectStatus" DEFAULT 'DRAFT'::public."ProjectStatus" NOT NULL,
    priority public."Priority" DEFAULT 'NORMAL'::public."Priority" NOT NULL,
    "startDate" timestamp(3) without time zone,
    "endDate" timestamp(3) without time zone,
    "budgetHours" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.projects OWNER TO postgres;

--
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "departmentId" text NOT NULL,
    "managerId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.services OWNER TO postgres;

--
-- Name: skills; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.skills (
    id text NOT NULL,
    name text NOT NULL,
    category public."SkillCategory" NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.skills OWNER TO postgres;

--
-- Name: task_dependencies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_dependencies (
    id text NOT NULL,
    "taskId" text NOT NULL,
    "dependsOnTaskId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.task_dependencies OWNER TO postgres;

--
-- Name: task_raci; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_raci (
    id text NOT NULL,
    "taskId" text NOT NULL,
    "userId" text NOT NULL,
    role public."RACIRole" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.task_raci OWNER TO postgres;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasks (
    id text NOT NULL,
    title text NOT NULL,
    description text,
    status public."TaskStatus" DEFAULT 'TODO'::public."TaskStatus" NOT NULL,
    priority public."Priority" DEFAULT 'NORMAL'::public."Priority" NOT NULL,
    "projectId" text NOT NULL,
    "epicId" text,
    "milestoneId" text,
    "assigneeId" text,
    "estimatedHours" double precision,
    progress integer DEFAULT 0 NOT NULL,
    "startDate" timestamp(3) without time zone,
    "endDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.tasks OWNER TO postgres;

--
-- Name: telework_schedules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.telework_schedules (
    id text NOT NULL,
    "userId" text NOT NULL,
    date date NOT NULL,
    "isTelework" boolean NOT NULL,
    "isException" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.telework_schedules OWNER TO postgres;

--
-- Name: time_entries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.time_entries (
    id text NOT NULL,
    "userId" text NOT NULL,
    "projectId" text,
    "taskId" text,
    date date NOT NULL,
    hours double precision NOT NULL,
    description text,
    "activityType" public."ActivityType" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.time_entries OWNER TO postgres;

--
-- Name: user_services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_services (
    id text NOT NULL,
    "userId" text NOT NULL,
    "serviceId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_services OWNER TO postgres;

--
-- Name: user_skills; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_skills (
    "userId" text NOT NULL,
    "skillId" text NOT NULL,
    level public."SkillLevel" NOT NULL,
    "validatedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.user_skills OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    login text NOT NULL,
    "passwordHash" text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    role public."Role" DEFAULT 'CONTRIBUTEUR'::public."Role" NOT NULL,
    "departmentId" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "avatarUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
004a3902-525d-4919-a20e-268cc7e9e731	ab1207c130891d46adce71b1900c8a29ae746a0bdb83b38725baf63d908f277d	2025-11-18 12:35:45.311783+00	20251116093059_init	\N	\N	2025-11-18 12:35:45.220735+00	1
139d4764-3fa9-4a03-8cfa-d416d714b4e2	1f2ee68ba302f59518d0bbdeab16a5c60037c745fb6e5b60bd5a98e94f4b9806	2025-11-20 14:57:43.444245+00	20251120145736_add_personal_todos	\N	\N	2025-11-20 14:57:43.424357+00	1
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.comments (id, content, "taskId", "authorId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.departments (id, name, description, "managerId", "createdAt", "updatedAt") FROM stdin;
cm3k9abc123def456	Direction des Systèmes d'Information	DSI - Technologies et innovation	\N	2025-11-18 12:37:06.965	2025-11-18 12:37:06.965
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.documents (id, name, description, url, "mimeType", size, "projectId", "uploadedBy", "createdAt") FROM stdin;
\.


--
-- Data for Name: epics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.epics (id, name, description, "projectId", progress, "startDate", "endDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: leaves; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.leaves (id, "userId", type, "startDate", "endDate", "halfDay", days, status, comment, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: milestones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.milestones (id, name, description, "projectId", "dueDate", status, "createdAt", "updatedAt") FROM stdin;
550e8400-e29b-41d4-a716-446655440001	Phase 1 - Analyse et Conception	Analyse des besoins, maquettes UX/UI et architecture technique	550e8400-e29b-41d4-a716-446655440000	2025-12-15 00:00:00	COMPLETED	2025-11-18 12:58:40.055	2025-11-18 12:58:40.055
550e8400-e29b-41d4-a716-446655440002	Phase 2 - Développement	Développement frontend et backend, intégration des fonctionnalités	550e8400-e29b-41d4-a716-446655440000	2026-01-31 00:00:00	IN_PROGRESS	2025-11-18 12:58:40.055	2025-11-18 12:58:40.055
550e8400-e29b-41d4-a716-446655440003	Phase 3 - Tests et Déploiement	Tests utilisateurs, corrections et mise en production	550e8400-e29b-41d4-a716-446655440000	2026-02-28 00:00:00	PENDING	2025-11-18 12:58:40.055	2025-11-18 12:58:40.055
7d626a8a-0387-46e6-9821-67cec78d8513	Test2	Test2	1905af45-0b4d-4e79-8994-b3e1258b1c81	2025-11-21 00:00:00	PENDING	2025-11-18 15:03:16.043	2025-11-18 15:46:26.129
\.


--
-- Data for Name: personal_todos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personal_todos (id, "userId", text, completed, "createdAt", "completedAt", "updatedAt") FROM stdin;
2ac6eb66-ddf8-44ee-9f0c-a8f9e8208c85	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	Test	t	2025-11-20 15:00:37.86	2025-11-20 15:00:48.425	2025-11-20 15:00:48.426
cee623e0-80ba-4c64-bd94-9dcabad34dee	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	test 2	f	2025-11-20 15:14:20.071	\N	2025-11-20 15:14:29.291
\.


--
-- Data for Name: project_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_members (id, "projectId", "userId", role, allocation, "startDate", "endDate", "createdAt") FROM stdin;
550e8400-e29b-41d4-a716-446655440010	550e8400-e29b-41d4-a716-446655440000	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	MANAGER	100	2025-11-18 12:58:40.055	\N	2025-11-18 12:58:40.055
f9f069bd-0719-4086-9751-35067b39b7c4	550e8400-e29b-41d4-a716-446655440000	70297a7e-f657-4e17-a652-cb4dde0c2073	Chef de projet	100	\N	\N	2025-11-20 14:19:49.894
6ff11487-13d4-40f8-90e1-51aa700f0115	550e8400-e29b-41d4-a716-446655440000	78ee53a1-88e8-474b-8025-1007ec999bc2	Membre	10	\N	\N	2025-11-20 14:20:03.927
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projects (id, name, description, status, priority, "startDate", "endDate", "budgetHours", "createdAt", "updatedAt") FROM stdin;
550e8400-e29b-41d4-a716-446655440000	Refonte Site Web Municipal	Refonte complète du site web de la commune avec un nouveau design moderne et responsive	ACTIVE	HIGH	2025-11-01 00:00:00	2026-02-28 00:00:00	480	2025-11-18 12:58:40.055	2025-11-18 12:58:40.055
1905af45-0b4d-4e79-8994-b3e1258b1c81	TEST	TEST	DRAFT	NORMAL	2025-11-17 00:00:00	2025-12-07 00:00:00	\N	2025-11-18 14:16:45.488	2025-11-18 14:16:45.488
04f15151-c22d-4527-b933-78afce468d7d	Projet de test	Premier projet de test	ACTIVE	NORMAL	2025-11-18 15:57:57.98	\N	100	2025-11-18 15:57:57.981	2025-11-18 15:57:57.981
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.services (id, name, description, "departmentId", "managerId", "createdAt", "updatedAt") FROM stdin;
897d1908-208b-46ee-a48e-27c63de757dd	Service Helpdesk	Support utilisateur et assistance technique	cm3k9abc123def456	\N	2025-11-18 15:57:57.911	2025-11-18 15:57:57.911
ae1eaf04-8146-4ee8-bd77-9dc08054d30c	Service Administration Système	Gestion des infrastructures et systèmes	cm3k9abc123def456	\N	2025-11-18 15:57:57.915	2025-11-18 15:57:57.915
fa4dec14-0cd5-404a-ab7b-c8f674edd418	Service Développement	Développement d'applications et logiciels	cm3k9abc123def456	\N	2025-11-18 15:57:57.917	2025-11-18 15:57:57.917
\.


--
-- Data for Name: skills; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.skills (id, name, category, description, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: task_dependencies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_dependencies (id, "taskId", "dependsOnTaskId", "createdAt") FROM stdin;
\.


--
-- Data for Name: task_raci; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_raci (id, "taskId", "userId", role, "createdAt") FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (id, title, description, status, priority, "projectId", "epicId", "milestoneId", "assigneeId", "estimatedHours", progress, "startDate", "endDate", "createdAt", "updatedAt") FROM stdin;
550e8400-e29b-41d4-a716-446655440100	Analyse des besoins utilisateurs	Recueillir et documenter les besoins des utilisateurs finaux	DONE	HIGH	550e8400-e29b-41d4-a716-446655440000	\N	550e8400-e29b-41d4-a716-446655440001	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	16	100	2025-11-01 00:00:00	2025-11-08 00:00:00	2025-11-18 12:59:10.682	2025-11-18 12:59:10.682
550e8400-e29b-41d4-a716-446655440101	Conception de l'architecture technique	Définir la stack technique et l'architecture du site	DONE	CRITICAL	550e8400-e29b-41d4-a716-446655440000	\N	550e8400-e29b-41d4-a716-446655440001	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	24	100	2025-11-09 00:00:00	2025-11-20 00:00:00	2025-11-18 12:59:10.682	2025-11-18 12:59:10.682
550e8400-e29b-41d4-a716-446655440102	Création des maquettes UX/UI	Designer les maquettes des pages principales	DONE	HIGH	550e8400-e29b-41d4-a716-446655440000	\N	550e8400-e29b-41d4-a716-446655440001	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	40	100	2025-11-15 00:00:00	2025-12-01 00:00:00	2025-11-18 12:59:10.682	2025-11-18 12:59:10.682
550e8400-e29b-41d4-a716-446655440103	Validation des maquettes	Présentation et validation avec les parties prenantes	DONE	NORMAL	550e8400-e29b-41d4-a716-446655440000	\N	550e8400-e29b-41d4-a716-446655440001	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	8	100	2025-12-02 00:00:00	2025-12-05 00:00:00	2025-11-18 12:59:10.682	2025-11-18 12:59:10.682
550e8400-e29b-41d4-a716-446655440104	Setup de l'environnement de développement	Configuration des outils et dépôt Git	DONE	HIGH	550e8400-e29b-41d4-a716-446655440000	\N	550e8400-e29b-41d4-a716-446655440001	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	12	100	2025-12-06 00:00:00	2025-12-10 00:00:00	2025-11-18 12:59:10.682	2025-11-18 12:59:10.682
550e8400-e29b-41d4-a716-446655440105	Développement de la page d'accueil	Intégrer la page d'accueil en HTML/CSS/JS	DONE	HIGH	550e8400-e29b-41d4-a716-446655440000	\N	550e8400-e29b-41d4-a716-446655440002	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	24	100	2025-12-11 00:00:00	2025-12-20 00:00:00	2025-11-18 12:59:10.682	2025-11-18 12:59:10.682
550e8400-e29b-41d4-a716-446655440106	Développement du système de navigation	Menu responsive et fil d'ariane	IN_REVIEW	NORMAL	550e8400-e29b-41d4-a716-446655440000	\N	550e8400-e29b-41d4-a716-446655440002	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	16	90	2025-12-21 00:00:00	2026-01-05 00:00:00	2025-11-18 12:59:10.682	2025-11-18 12:59:10.682
550e8400-e29b-41d4-a716-446655440107	Intégration du CMS	Installation et configuration du système de gestion de contenu	IN_PROGRESS	CRITICAL	550e8400-e29b-41d4-a716-446655440000	\N	550e8400-e29b-41d4-a716-446655440002	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	32	60	2026-01-06 00:00:00	2026-01-20 00:00:00	2025-11-18 12:59:10.682	2025-11-18 12:59:10.682
550e8400-e29b-41d4-a716-446655440108	Développement de l'espace citoyen	Module de connexion et tableau de bord citoyen	IN_PROGRESS	HIGH	550e8400-e29b-41d4-a716-446655440000	\N	550e8400-e29b-41d4-a716-446655440002	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	40	45	2026-01-08 00:00:00	2026-01-25 00:00:00	2025-11-18 12:59:10.682	2025-11-18 12:59:10.682
550e8400-e29b-41d4-a716-446655440109	Optimisation SEO	Balises meta, sitemap, robots.txt et performance	TODO	NORMAL	550e8400-e29b-41d4-a716-446655440000	\N	550e8400-e29b-41d4-a716-446655440002	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	12	0	2026-01-21 00:00:00	2026-01-27 00:00:00	2025-11-18 12:59:10.682	2025-11-18 12:59:10.682
550e8400-e29b-41d4-a716-446655440111	Intégration des API externes	Connecter les services tiers (météo, événements)	TODO	NORMAL	550e8400-e29b-41d4-a716-446655440000	\N	550e8400-e29b-41d4-a716-446655440002	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	16	0	2026-01-23 00:00:00	2026-01-31 00:00:00	2025-11-18 12:59:10.682	2025-11-18 12:59:10.682
550e8400-e29b-41d4-a716-446655440112	Tests utilisateurs	Organisation et réalisation des tests avec un panel d'utilisateurs	TODO	HIGH	550e8400-e29b-41d4-a716-446655440000	\N	550e8400-e29b-41d4-a716-446655440003	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	24	0	2026-02-01 00:00:00	2026-02-10 00:00:00	2025-11-18 12:59:10.682	2025-11-18 12:59:10.682
550e8400-e29b-41d4-a716-446655440110	Accessibilité RGAA	Conformité aux standards d'accessibilité	TODO	HIGH	550e8400-e29b-41d4-a716-446655440000	\N	550e8400-e29b-41d4-a716-446655440002	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	20	0	2026-01-22 00:00:00	2026-01-30 00:00:00	2025-11-18 12:59:10.682	2025-11-18 13:12:26.813
550e8400-e29b-41d4-a716-446655440113	Corrections et ajustements	Corriger les bugs et améliorer l'UX suite aux retours	TODO	CRITICAL	550e8400-e29b-41d4-a716-446655440000	\N	550e8400-e29b-41d4-a716-446655440003	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	32	0	2026-02-11 00:00:00	2026-02-20 00:00:00	2025-11-18 12:59:10.682	2025-11-18 12:59:10.682
550e8400-e29b-41d4-a716-446655440114	Déploiement en production	Mise en ligne finale et bascule DNS	TODO	CRITICAL	550e8400-e29b-41d4-a716-446655440000	\N	550e8400-e29b-41d4-a716-446655440003	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	16	0	2026-02-21 00:00:00	2026-02-28 00:00:00	2025-11-18 12:59:10.682	2025-11-18 12:59:10.682
b20066cf-04fe-4ec2-bac3-ceb811e3fb65	Test	Test	TODO	NORMAL	1905af45-0b4d-4e79-8994-b3e1258b1c81	\N	\N	\N	\N	0	2025-11-20 00:00:00	2025-11-21 00:00:00	2025-11-18 15:02:07.085	2025-11-18 15:23:20.732
c736f42a-6206-4a67-81de-0de1d726d36a	Test 2	Test 2	TODO	NORMAL	04f15151-c22d-4527-b933-78afce468d7d	\N	\N	8d686fa6-b0c8-44d8-a0a5-2d2eb68b4ce0	\N	0	2025-11-19 00:00:00	2025-11-21 00:00:00	2025-11-20 09:00:48.059	2025-11-20 09:45:02.981
629965f3-cf9c-4363-8671-c7a05eb3e3ed	Test	Test	TODO	NORMAL	550e8400-e29b-41d4-a716-446655440000	\N	550e8400-e29b-41d4-a716-446655440001	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	\N	0	2025-11-20 00:00:00	2025-11-25 00:00:00	2025-11-20 08:54:59.542	2025-11-20 09:55:38.952
\.


--
-- Data for Name: telework_schedules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.telework_schedules (id, "userId", date, "isTelework", "isException", "createdAt") FROM stdin;
9a899b0e-424a-4118-b0cd-256320095c67	70297a7e-f657-4e17-a652-cb4dde0c2073	2025-11-19	f	f	2025-11-19 15:19:56.826
4370c093-5ada-4c0f-8bf7-68fcb259c0f2	70297a7e-f657-4e17-a652-cb4dde0c2073	2025-11-18	f	f	2025-11-19 15:42:47.252
49dc270f-570a-4fe4-9643-b5b5e437ac96	70297a7e-f657-4e17-a652-cb4dde0c2073	2025-11-20	t	f	2025-11-19 15:42:42.825
351e15aa-6721-41cb-b103-eabe073731f3	70297a7e-f657-4e17-a652-cb4dde0c2073	2025-11-27	t	f	2025-11-19 15:43:06.519
35fa7684-d9d9-4f56-9ce9-2646b86106f6	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	2025-11-24	t	f	2025-11-19 15:50:33.507
9100b607-ca9b-46cb-bc01-ef8a3836aacb	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	2025-11-25	t	f	2025-11-19 15:50:35.902
6c5cd60e-51aa-4367-9bf8-20ca1634a40e	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	2025-11-21	t	f	2025-11-19 16:23:53.707
296aa7dd-9d40-481f-9230-5df9996a3658	admin001	2025-11-21	t	f	2025-11-19 15:45:06.285
118263f9-1057-406e-95fc-4e8a60d5bb57	107a8b00-f5c5-4dc4-a86c-2370a64b61cd	2025-11-20	t	f	2025-11-19 16:24:08.291
\.


--
-- Data for Name: time_entries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.time_entries (id, "userId", "projectId", "taskId", date, hours, description, "activityType", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: user_services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_services (id, "userId", "serviceId", "createdAt") FROM stdin;
0dd00181-b72e-4d78-939a-d846a6afe362	9d82d5a4-c786-4f1b-a017-831cbcd3fa02	897d1908-208b-46ee-a48e-27c63de757dd	2025-11-18 15:57:57.956
eb37fdd2-32f9-48eb-8891-f4c7fb46de5b	e59ebe38-bac8-4f96-a7a3-da4517b929b4	897d1908-208b-46ee-a48e-27c63de757dd	2025-11-18 15:57:57.956
f3e3af41-288c-4709-9192-d6a30a1de6f5	78ee53a1-88e8-474b-8025-1007ec999bc2	ae1eaf04-8146-4ee8-bd77-9dc08054d30c	2025-11-18 15:57:57.967
e45a8730-8461-40b5-b764-13a1c95c60b1	a4a05382-321b-4659-9356-0015e2a71190	fa4dec14-0cd5-404a-ab7b-c8f674edd418	2025-11-18 15:57:57.976
26f16a0a-5a6f-4ffe-bba2-8a64a034ee45	4d4f6e78-3d22-4dca-b399-9484a09f3887	fa4dec14-0cd5-404a-ab7b-c8f674edd418	2025-11-18 15:57:57.977
544388f1-a3ff-4b9e-9417-f23f0d064ea9	0b6ee4cc-7a5e-42ed-b66f-71d72a87b701	ae1eaf04-8146-4ee8-bd77-9dc08054d30c	2025-11-18 15:57:57.967
2d36d5e5-6b35-459d-bafc-3e0a4c69194b	5db16d3e-4855-44f0-a223-f3702fc203bb	fa4dec14-0cd5-404a-ab7b-c8f674edd418	2025-11-18 15:57:57.977
1edd4955-ebd5-42b8-957c-4184ba7da4e6	472c05d5-d56c-4800-8020-5c4e0f3f3c59	897d1908-208b-46ee-a48e-27c63de757dd	2025-11-18 15:57:57.955
fce20ad1-ddfd-4f7b-a2fc-4c2cd6cc6cc2	b814b5f5-f454-41ee-8cfd-b83efb0aac2e	897d1908-208b-46ee-a48e-27c63de757dd	2025-11-18 15:57:57.956
9a29e24f-0d5a-44e2-9aa2-2fe2d813fdf3	8d686fa6-b0c8-44d8-a0a5-2d2eb68b4ce0	ae1eaf04-8146-4ee8-bd77-9dc08054d30c	2025-11-18 15:57:57.967
69b674a5-4c32-4c5e-9c6b-e44c43050240	806f994c-44cd-4cda-8e55-38996ff1f558	ae1eaf04-8146-4ee8-bd77-9dc08054d30c	2025-11-18 15:57:57.967
e0a997cd-ed62-4ddf-aaff-89157676f580	527a5c27-e064-494d-b653-efa865a3590d	fa4dec14-0cd5-404a-ab7b-c8f674edd418	2025-11-18 15:57:57.976
709fe3c4-5750-4e31-9474-029373b38a62	c8ec6bc5-f1c3-4a43-986b-4f782ddb7ad8	fa4dec14-0cd5-404a-ab7b-c8f674edd418	2025-11-18 15:57:57.977
57d03298-2160-4930-ba2f-f0bc3f645e7f	70297a7e-f657-4e17-a652-cb4dde0c2073	897d1908-208b-46ee-a48e-27c63de757dd	2025-11-19 14:22:55.749
b26c10ac-8ae0-4140-9dbb-5daa731667f3	3598e46c-69e3-4788-9ac6-13b4df58cbf5	ae1eaf04-8146-4ee8-bd77-9dc08054d30c	2025-11-19 14:46:12.897
17fd38e2-723b-4f4b-a11f-d1cb26350eeb	3598e46c-69e3-4788-9ac6-13b4df58cbf5	fa4dec14-0cd5-404a-ab7b-c8f674edd418	2025-11-19 14:46:12.897
efe32c68-e681-41cb-88b6-33dc797814ba	3598e46c-69e3-4788-9ac6-13b4df58cbf5	897d1908-208b-46ee-a48e-27c63de757dd	2025-11-19 14:46:12.897
\.


--
-- Data for Name: user_skills; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_skills ("userId", "skillId", level, "validatedBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, login, "passwordHash", "firstName", "lastName", role, "departmentId", "isActive", "avatarUrl", "createdAt", "updatedAt") FROM stdin;
107a8b00-f5c5-4dc4-a86c-2370a64b61cd	admin2@orchestr-a.internal	admin2	$2b$12$7GCtYpm69.lKIwb8OJZPoulhVEvxfJ1nrj9fK.8CTe2EZr19QS44a	Admin	System	ADMIN	cm3k9abc123def456	t	\N	2025-11-18 12:38:26.517	2025-11-18 12:38:26.517
472c05d5-d56c-4800-8020-5c4e0f3f3c59	sophie.martin@orchestr-a.internal	smartin	$2b$12$vI3W06KqOPjBiGN8qXDBIuiSsdM1KyN2UJJAUkk400Da2YqETfPsG	Sophie	Martin	CONTRIBUTEUR	cm3k9abc123def456	t	\N	2025-11-18 15:57:57.919	2025-11-18 15:57:57.919
e59ebe38-bac8-4f96-a7a3-da4517b929b4	marie.lefevre@orchestr-a.internal	mlefevre	$2b$12$vI3W06KqOPjBiGN8qXDBIuiSsdM1KyN2UJJAUkk400Da2YqETfPsG	Marie	Lefevre	CONTRIBUTEUR	cm3k9abc123def456	t	\N	2025-11-18 15:57:57.919	2025-11-18 15:57:57.919
9d82d5a4-c786-4f1b-a017-831cbcd3fa02	nicolas.rousseau@orchestr-a.internal	nrousseau	$2b$12$vI3W06KqOPjBiGN8qXDBIuiSsdM1KyN2UJJAUkk400Da2YqETfPsG	Nicolas	Rousseau	CONTRIBUTEUR	cm3k9abc123def456	t	\N	2025-11-18 15:57:57.919	2025-11-18 15:57:57.919
b814b5f5-f454-41ee-8cfd-b83efb0aac2e	julie.dubois@orchestr-a.internal	jdubois	$2b$12$vI3W06KqOPjBiGN8qXDBIuiSsdM1KyN2UJJAUkk400Da2YqETfPsG	Julie	Dubois	CONTRIBUTEUR	cm3k9abc123def456	t	\N	2025-11-18 15:57:57.92	2025-11-18 15:57:57.92
0b6ee4cc-7a5e-42ed-b66f-71d72a87b701	pierre.moreau@orchestr-a.internal	pmoreau	$2b$12$vI3W06KqOPjBiGN8qXDBIuiSsdM1KyN2UJJAUkk400Da2YqETfPsG	Pierre	Moreau	CONTRIBUTEUR	cm3k9abc123def456	t	\N	2025-11-18 15:57:57.961	2025-11-18 15:57:57.961
8d686fa6-b0c8-44d8-a0a5-2d2eb68b4ce0	isabelle.simon@orchestr-a.internal	isimon	$2b$12$vI3W06KqOPjBiGN8qXDBIuiSsdM1KyN2UJJAUkk400Da2YqETfPsG	Isabelle	Simon	CONTRIBUTEUR	cm3k9abc123def456	t	\N	2025-11-18 15:57:57.961	2025-11-18 15:57:57.961
806f994c-44cd-4cda-8e55-38996ff1f558	alexandre.roux@orchestr-a.internal	aroux	$2b$12$vI3W06KqOPjBiGN8qXDBIuiSsdM1KyN2UJJAUkk400Da2YqETfPsG	Alexandre	Roux	CONTRIBUTEUR	cm3k9abc123def456	t	\N	2025-11-18 15:57:57.962	2025-11-18 15:57:57.962
78ee53a1-88e8-474b-8025-1007ec999bc2	celine.garcia@orchestr-a.internal	cgarcia	$2b$12$vI3W06KqOPjBiGN8qXDBIuiSsdM1KyN2UJJAUkk400Da2YqETfPsG	Céline	Garcia	CONTRIBUTEUR	cm3k9abc123def456	t	\N	2025-11-18 15:57:57.963	2025-11-18 15:57:57.963
a4a05382-321b-4659-9356-0015e2a71190	emma.petit@orchestr-a.internal	epetit	$2b$12$vI3W06KqOPjBiGN8qXDBIuiSsdM1KyN2UJJAUkk400Da2YqETfPsG	Emma	Petit	CONTRIBUTEUR	cm3k9abc123def456	t	\N	2025-11-18 15:57:57.971	2025-11-18 15:57:57.971
527a5c27-e064-494d-b653-efa865a3590d	maxime.durand@orchestr-a.internal	mdurand	$2b$12$vI3W06KqOPjBiGN8qXDBIuiSsdM1KyN2UJJAUkk400Da2YqETfPsG	Maxime	Durand	CONTRIBUTEUR	cm3k9abc123def456	t	\N	2025-11-18 15:57:57.971	2025-11-18 15:57:57.971
c8ec6bc5-f1c3-4a43-986b-4f782ddb7ad8	camille.laurent@orchestr-a.internal	claurent	$2b$12$vI3W06KqOPjBiGN8qXDBIuiSsdM1KyN2UJJAUkk400Da2YqETfPsG	Camille	Laurent	CONTRIBUTEUR	cm3k9abc123def456	t	\N	2025-11-18 15:57:57.972	2025-11-18 15:57:57.972
4d4f6e78-3d22-4dca-b399-9484a09f3887	hugo.girard@orchestr-a.internal	hgirard	$2b$12$vI3W06KqOPjBiGN8qXDBIuiSsdM1KyN2UJJAUkk400Da2YqETfPsG	Hugo	Girard	CONTRIBUTEUR	cm3k9abc123def456	t	\N	2025-11-18 15:57:57.973	2025-11-18 15:57:57.973
5db16d3e-4855-44f0-a223-f3702fc203bb	lea.fontaine@orchestr-a.internal	lfontaine	$2b$12$vI3W06KqOPjBiGN8qXDBIuiSsdM1KyN2UJJAUkk400Da2YqETfPsG	Léa	Fontaine	CONTRIBUTEUR	cm3k9abc123def456	t	\N	2025-11-18 15:57:57.972	2025-11-18 15:57:57.972
70297a7e-f657-4e17-a652-cb4dde0c2073	thomas.bernard@orchestr-a.internal	tbernard	$2b$12$vI3W06KqOPjBiGN8qXDBIuiSsdM1KyN2UJJAUkk400Da2YqETfPsG	Thomas	Bernard	MANAGER	cm3k9abc123def456	t	\N	2025-11-18 15:57:57.919	2025-11-19 14:22:55.752
3598e46c-69e3-4788-9ac6-13b4df58cbf5	laurent.michel@orchestr-a.internal	lmichel	$2b$12$vI3W06KqOPjBiGN8qXDBIuiSsdM1KyN2UJJAUkk400Da2YqETfPsG	Laurent	Michel	RESPONSABLE	cm3k9abc123def456	t	\N	2025-11-18 15:57:57.962	2025-11-19 14:46:12.9
admin001	admin@orchestr-a.internal	admin	$2b$12$vI3W06KqOPjBiGN8qXDBIuiSsdM1KyN2UJJAUkk400Da2YqETfPsG	Admin	ORCHESTR'A	ADMIN	cm3k9abc123def456	t	\N	2025-11-18 12:37:58.895	2025-11-18 12:37:58.895
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: epics epics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.epics
    ADD CONSTRAINT epics_pkey PRIMARY KEY (id);


--
-- Name: leaves leaves_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leaves
    ADD CONSTRAINT leaves_pkey PRIMARY KEY (id);


--
-- Name: milestones milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_pkey PRIMARY KEY (id);


--
-- Name: personal_todos personal_todos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_todos
    ADD CONSTRAINT personal_todos_pkey PRIMARY KEY (id);


--
-- Name: project_members project_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_members
    ADD CONSTRAINT project_members_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: skills skills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_pkey PRIMARY KEY (id);


--
-- Name: task_dependencies task_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_dependencies
    ADD CONSTRAINT task_dependencies_pkey PRIMARY KEY (id);


--
-- Name: task_raci task_raci_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_raci
    ADD CONSTRAINT task_raci_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: telework_schedules telework_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telework_schedules
    ADD CONSTRAINT telework_schedules_pkey PRIMARY KEY (id);


--
-- Name: time_entries time_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_pkey PRIMARY KEY (id);


--
-- Name: user_services user_services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_services
    ADD CONSTRAINT user_services_pkey PRIMARY KEY (id);


--
-- Name: user_skills user_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_skills
    ADD CONSTRAINT user_skills_pkey PRIMARY KEY ("userId", "skillId");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: personal_todos_userId_completed_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "personal_todos_userId_completed_createdAt_idx" ON public.personal_todos USING btree ("userId", completed, "createdAt");


--
-- Name: project_members_projectId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "project_members_projectId_userId_key" ON public.project_members USING btree ("projectId", "userId");


--
-- Name: skills_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX skills_name_key ON public.skills USING btree (name);


--
-- Name: task_dependencies_taskId_dependsOnTaskId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "task_dependencies_taskId_dependsOnTaskId_key" ON public.task_dependencies USING btree ("taskId", "dependsOnTaskId");


--
-- Name: task_raci_taskId_userId_role_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "task_raci_taskId_userId_role_key" ON public.task_raci USING btree ("taskId", "userId", role);


--
-- Name: telework_schedules_userId_date_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "telework_schedules_userId_date_key" ON public.telework_schedules USING btree ("userId", date);


--
-- Name: user_services_userId_serviceId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "user_services_userId_serviceId_key" ON public.user_services USING btree ("userId", "serviceId");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_login_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_login_key ON public.users USING btree (login);


--
-- Name: comments comments_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT "comments_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: comments comments_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT "comments_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public.tasks(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: departments departments_managerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT "departments_managerId_fkey" FOREIGN KEY ("managerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: documents documents_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: epics epics_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.epics
    ADD CONSTRAINT "epics_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: leaves leaves_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leaves
    ADD CONSTRAINT "leaves_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: milestones milestones_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT "milestones_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: personal_todos personal_todos_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_todos
    ADD CONSTRAINT "personal_todos_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_members project_members_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_members
    ADD CONSTRAINT "project_members_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_members project_members_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_members
    ADD CONSTRAINT "project_members_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: services services_departmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT "services_departmentId_fkey" FOREIGN KEY ("departmentId") REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: services services_managerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT "services_managerId_fkey" FOREIGN KEY ("managerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: task_dependencies task_dependencies_dependsOnTaskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_dependencies
    ADD CONSTRAINT "task_dependencies_dependsOnTaskId_fkey" FOREIGN KEY ("dependsOnTaskId") REFERENCES public.tasks(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: task_dependencies task_dependencies_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_dependencies
    ADD CONSTRAINT "task_dependencies_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public.tasks(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: task_raci task_raci_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_raci
    ADD CONSTRAINT "task_raci_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public.tasks(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tasks tasks_assigneeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT "tasks_assigneeId_fkey" FOREIGN KEY ("assigneeId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tasks tasks_epicId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT "tasks_epicId_fkey" FOREIGN KEY ("epicId") REFERENCES public.epics(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tasks tasks_milestoneId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT "tasks_milestoneId_fkey" FOREIGN KEY ("milestoneId") REFERENCES public.milestones(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tasks tasks_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT "tasks_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: telework_schedules telework_schedules_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telework_schedules
    ADD CONSTRAINT "telework_schedules_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: time_entries time_entries_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT "time_entries_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: time_entries time_entries_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT "time_entries_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public.tasks(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: time_entries time_entries_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT "time_entries_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_services user_services_serviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_services
    ADD CONSTRAINT "user_services_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES public.services(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_services user_services_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_services
    ADD CONSTRAINT "user_services_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_skills user_skills_skillId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_skills
    ADD CONSTRAINT "user_skills_skillId_fkey" FOREIGN KEY ("skillId") REFERENCES public.skills(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_skills user_skills_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_skills
    ADD CONSTRAINT "user_skills_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_departmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_departmentId_fkey" FOREIGN KEY ("departmentId") REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict qwvdIi7kRtgR75f1DUXmQ0jIn6DupfuflyOkIiALEXjHU9y23bF2wbZg8R3rXzl

